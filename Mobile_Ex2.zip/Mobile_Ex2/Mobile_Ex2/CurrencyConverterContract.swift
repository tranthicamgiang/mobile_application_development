//
//  CurrencyConverterContract.swift
//  Mobile_Ex2
//
//  Created by Tran Thi Cam Giang on 4/22/18.
//  Copyright (c) 2018 Tran Thi Cam Giang. All rights reserved.
//

import UIKit

protocol CurrencyConverterBusinessLogic {
   func loadData()
   func getCountOfCurrency() -> Int
   func convert(from: String, to: String, amount: Float) -> Float
}

protocol CurrencyConverterDataStore {
   
}

protocol CurrencyConverterPresentationLogic {
   func presentSomething(response: CurrencyConverter.Something.Response)
}

@objc protocol CurrencyConverterRoutingLogic {
   //func routeToSomewhere(segue: UIStoryboardSegue?)
}

protocol CurrencyConverterDataPassing {
   var dataStore: CurrencyConverterDataStore? { get }
}

protocol CurrencyConverterDisplayLogic: class {
   func displaySomething(viewModel: CurrencyConverter.Something.ViewModel)
}


protocol CurrencyConverterBuilderLogic {
   func build() -> UIViewController
}


