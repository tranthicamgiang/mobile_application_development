//
//  Api.swift
//  Mobile_Ex2
//
//  Created by Tran Thi Cam Giang on 4/22/18.
//  Copyright © 2018 Tran Thi Cam Giang. All rights reserved.
//

import Foundation
import Moya

let accessKey = "57ad1c2fb4ac3248be8b75825dc2068c"
enum Api {
   
   case getExchangeRate(currencies: [String])
}

extension Api: TargetType {
   
   var headers: [String : String]? {
      return nil
   }
   
   var baseURL: URL {
      return URL(string: "http://apilayer.net/api")!
   }
   
   var path: String {
      return "/live"
   }
   
   var method: Moya.Method {
      return .get
   }
   
   var sampleData: Data {
      return Data()
   }
   
   var task: Task {
      switch self {
      case .getExchangeRate(let currencies):
         let currenciesStr = currencies.joined(separator: ",")
         if currencies.count > 0 {
            return .requestParameters(parameters: ["access_key": accessKey,
                                                   "currencies": currenciesStr,
                                                   "source": "USD",
                                                   "format": 1],
                                      encoding: URLEncoding.default)
         } else {
            return .requestParameters(parameters: ["access_key": accessKey,
                                                   "source": "USD",
                                                   "format": 1],
                                      encoding: URLEncoding.default)
         }
         
      }
      
   }
}

