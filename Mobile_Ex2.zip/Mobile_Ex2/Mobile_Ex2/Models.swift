//
//  Models.swift
//  Mobile_Ex2
//
//  Created by Tran Thi Cam Giang on 4/22/18.
//  Copyright © 2018 Tran Thi Cam Giang. All rights reserved.
//

import Foundation

struct ApiResponse: Decodable {
   var source: String
   var currencies: [String: Float]
   
   init(source: String, currencies: [String: Float]) {
      self.source = source
      self.currencies = currencies
   }
   
   enum CodingKeys: String, CodingKey {
      case source = "source"
      case currency = "quotes"
   }
   
   init(from decoder: Decoder) throws {
      let container = try decoder.container(keyedBy: CodingKeys.self)
      self.source = try container.decode(String.self, forKey: .source)
      self.currencies = [:]
      
      let c = try container.decode([String: Float].self, forKey: .currency)
      let formatCurrencies = c.map { (key, value) -> (String, Float) in
         guard key.count > self.source.count else {
            return (key, value)
         }
         return (key.substring(from: self.source.endIndex), value)
      }
      
      formatCurrencies.forEach { (s, f) in
         self.currencies[s] = f
      }
   }
}
