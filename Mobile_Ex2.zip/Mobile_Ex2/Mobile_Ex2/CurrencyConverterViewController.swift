//
//  CurrencyConverterViewController.swift
//  Mobile_Ex2
//
//  Created by Tran Thi Cam Giang on 4/22/18.
//  Copyright (c) 2018 Tran Thi Cam Giang. All rights reserved.
//


import UIKit


final class CurrencyConverterViewController: UIViewController, CurrencyConverterDisplayLogic {
   
   @IBOutlet weak var amount: UITextField!
   
   @IBOutlet weak var to: UITextField!
   @IBOutlet weak var picker: UIPickerView!

   @IBOutlet weak var result: UILabel!
   @IBAction func onClick(_ sender: UIButton) {
      var toTxt: String
      var amountValue: Float
      
      if to.text == nil {
         toTxt = ""
      } else {
         toTxt = (to.text!).uppercased()
      }
      
      if amount.text == nil {
         amountValue = 0
      } else {
         amountValue = (amount.text! as NSString).floatValue
         
      }
      
      let res = interactor?.convert(from: "USD", to: toTxt, amount: amountValue)
      result.text = res?.description
   }
   
   var interactor: CurrencyConverterBusinessLogic?
   var router: (NSObjectProtocol & CurrencyConverterRoutingLogic & CurrencyConverterDataPassing)?
   
   // MARK: Object lifecycle
   
   override init(nibName nibNameOrNil: String? = "CurrencyConverterViewController", bundle nibBundleOrNil: Bundle? = nil) {
      super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
   }
   
   required init?(coder aDecoder: NSCoder) {
      super.init(coder: aDecoder)
   }
   
   // MARK: View lifecycle
   
   override func viewDidLoad() {
      super.viewDidLoad()
      loadInitialData()
      
      picker.isHidden = true
   }
   
   // MARK: Do something
   func loadInitialData() {
      interactor?.loadData()
   }
   
   func displaySomething(viewModel: CurrencyConverter.Something.ViewModel) {
      
   }
   
   
}

extension CurrencyConverterViewController: UIPickerViewDataSource {
   func numberOfComponents(in pickerView: UIPickerView) -> Int {
      return 1
   }
   
   func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//      return (interactor?.getCountOfCurrency())!
      return 0
   }
}

extension CurrencyConverterViewController: UIPickerViewDelegate {
   func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
      return to.bounds.size.width
   }
   
   func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
      return 30.0
   }
}


