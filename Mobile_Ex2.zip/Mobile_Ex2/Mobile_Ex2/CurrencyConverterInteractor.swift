//
//  CurrencyConverterInteractor.swift
//  Mobile_Ex2
//
//  Created by Tran Thi Cam Giang on 4/22/18.
//  Copyright (c) 2018 Tran Thi Cam Giang. All rights reserved.
//

import UIKit
import Moya

final class CurrencyConverterInteractor: CurrencyConverterBusinessLogic, CurrencyConverterDataStore {
   func convert(from: String, to: String, amount: Float) -> Float {
      guard let data = data else {
         return 0
      }
      
      guard let rate = data.currencies[to] else {
         return 0
      }
      return rate * amount
   }
   
   var data: ApiResponse?
   func getCountOfCurrency() -> Int {
      if data == nil {
         loadData()
         return data!.currencies.count
      }
      
      return data!.currencies.count
   }
   
   var presenter: CurrencyConverterPresentationLogic?
   var worker: CurrencyConverterWorker?
   
   // MARK: Do something
   
   func loadData() {

      let provider = MoyaProvider<Api>()
      
      provider.request(.getExchangeRate(currencies: [])) { (result) in
         switch result {
         case .success(let response):
            print(response.data)
            let decoder = JSONDecoder()
            do {
               self.data = try decoder.decode(ApiResponse.self, from: response.data)
            } catch {
               print(error)
               
            }
            
         case .failure(let error):
            
            print(error)
         }
         
      }
   }
   
   
}
