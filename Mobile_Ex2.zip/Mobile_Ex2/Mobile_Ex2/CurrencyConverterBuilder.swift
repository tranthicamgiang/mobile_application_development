//
//  CurrencyConverterBuilder.swift
//  Mobile_Ex2
//
//  Created by Tran Thi Cam Giang on 4/22/18.
//  Copyright (c) 2018 Tran Thi Cam Giang. All rights reserved.
//

import UIKit
import Moya

final class CurrencyConverterSceneBuilder: CurrencyConverterBuilderLogic {
   func build() -> UIViewController {
      let viewController = CurrencyConverterViewController()
      let interactor = CurrencyConverterInteractor()
      let presenter = CurrencyConverterPresenter()
      let router = CurrencyConverterRouter()
      viewController.interactor = interactor
      viewController.router = router
      interactor.presenter = presenter
      presenter.viewController = viewController
      router.viewController = viewController
      router.dataStore = interactor
      
      return viewController
   }
}
