//
//  CurrencyConverterPresenter.swift
//  Mobile_Ex2
//
//  Created by Tran Thi Cam Giang on 4/22/18.
//  Copyright (c) 2018 Tran Thi Cam Giang. All rights reserved.
//

import UIKit

final class CurrencyConverterPresenter: CurrencyConverterPresentationLogic {
   weak var viewController: CurrencyConverterDisplayLogic?
   
   // MARK: Do something
   
   func presentSomething(response: CurrencyConverter.Something.Response) {
      let viewModel = CurrencyConverter.Something.ViewModel()
      viewController?.displaySomething(viewModel: viewModel)
   }
}
